/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;

import javax.swing.JOptionPane;
import dao.Conexao;
import java.sql.*;

/**
 *
 * @author Rafael F Oliveira <rafael.felipe@edu.sc.senai.br>
 */
public class LoginBack {
    
    Connection conexao = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    public boolean autenticar(String usuario, String senha) { 
        boolean autenticado = false;
        try {
            conexao = Conexao.conector();
            String sql = "select * from usuario where nm_usuario = ? and ds_senha = ?";
            ps = conexao.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, senha);
            rs = ps.executeQuery();

            if (rs.next()) {
                autenticado = true; 
            }

        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Problema ao tentar realizar LOGIN");
        } finally {
            try {
                conexao.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return autenticado;
    }                      
}
